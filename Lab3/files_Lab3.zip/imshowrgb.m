function imshowrgb(r,g,b)

A(:,:,1)=r;
A(:,:,2)=g;
A(:,:,3)=b;

imshow(A)